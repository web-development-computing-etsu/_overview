document.write('<span style="position:fixed; left:5px; bottom:0px; padding:0;">');
document.write('		<a style="padding:0;" href="http://validator.w3.org/check/referer" target="_blank">');
document.write('			<img style="display:inline; padding:0;" src="/images/html5cert.png" alt="html5 validator"></a>');
document.write('		&nbsp;&nbsp;');
document.write('		<a style="padding:0;" href="http://jigsaw.w3.org/css-validator/check/referer" target="_blank">');
document.write('			<img style="display:inline; padding:0;" src="/images/css3cert.png" alt="css validator"></a>');
document.write('</span>');	
		
